package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@ResponseBody

public class HelloController {

	@RequestMapping("hello")
	
	public String hello(@RequestParam(name="firstname", required=false, defaultValue="Our World") String firstName, String location) {
		
	
		return "Welcome to the " + location + " " + firstName + " !";
	}
	

	@RequestMapping("main")
	
	public String main() {
	
		return "Wellcome to the main page";
	}
	

	@RequestMapping("contact")
	
	public String contact() {
	
		return "Wellcome to the contact page and keep in touch with us!";
	}

}
